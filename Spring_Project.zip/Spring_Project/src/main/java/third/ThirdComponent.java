package third;

import org.springframework.stereotype.Component;

@Component
public class ThirdComponent {
public void doTest() {
	System.out.println("ThirdComponent test succeeded");
}
}
