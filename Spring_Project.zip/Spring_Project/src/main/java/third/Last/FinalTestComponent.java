package third.Last;

import org.springframework.stereotype.Component;

//Assigining on ID:myfinalcomp to this component so that it can be accessed using the same.
@Component("myFinalComp")
public class FinalTestComponent {
public void doTest() {
	System.out.println("finalTestComponent test succeeded");
	
}
}
