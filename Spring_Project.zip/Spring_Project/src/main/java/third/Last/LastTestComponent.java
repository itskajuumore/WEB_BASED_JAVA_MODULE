package third.Last;

import org.springframework.stereotype.Component;

@Component
public class LastTestComponent {
public void doTest() {
	System.out.println("LastTestComponent test succeeded");
}
}
