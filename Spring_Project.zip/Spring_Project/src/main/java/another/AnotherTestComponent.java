package another;

import org.springframework.stereotype.Component;

@Component

public class AnotherTestComponent{
	public void doTest() {
		System.out.println("AnotherTestComponent test succeeded.");
	}
}
