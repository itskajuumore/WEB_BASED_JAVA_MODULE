package example.spring.core.without_xml.auto_wiring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class AppSpringConfig {
//Configuration of 3 beans:Engine, MusicSystem and Car
	@Bean("carengine")

	public Engine getEngine() {
		Engine eng= new Engine("1600 CC", "petrol");
		return eng;
	}
	
	@Bean("carSuperengine2")
	@Primary
	public Engine getSuperEngine() {
		Engine eng= new Engine("1600 CC", "petrol");
		return eng;
	}
		
	//@Bean("carMusicSystem")
	public MusicSystem getMusicSystem() {
		MusicSystem ms= new MusicSystem();
		ms.setMake("sony");
		ms.setSounEffect("Dolby");
		return ms;
	}
	
	@Bean("myCar")
	public Car getMyCar() {
		Car myCar=new Car();
		myCar.setMake("hundai");
		myCar.setModel("Creta");
		myCar.setPrice("23000");
		return myCar;
	}
//	Did not set values for engineDetails and musicSystemDetails
	//properties because they will get auto wired.
}


