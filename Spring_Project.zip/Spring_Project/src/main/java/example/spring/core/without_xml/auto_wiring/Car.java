package example.spring.core.without_xml.auto_wiring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Car {
	private String make;
	private String model;
	private String price;
	@Autowired
	@Qualifier("carSuperengine"
			+ "")
	private Engine engineDetails;
	@Autowired(required=false)
	private MusicSystem MusicSystemDetails;

	public Car() {
		
	}

	public Car(String make, String model, String price, Engine engineDetails, MusicSystem musicSystemDetails) {
		super();
		this.make = make;
		this.model = model;
		this.price = price;
		this.engineDetails = engineDetails;
		MusicSystemDetails = musicSystemDetails;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public Engine getEngineDetails() {
		return engineDetails;
	}

	public void setEngineDetails(Engine engineDetails) {
		this.engineDetails = engineDetails;
	}

	public MusicSystem getMusicSystemDetails() {
		return MusicSystemDetails;
	}

	public void setMusicSystemDetails(MusicSystem musicSystemDetails) {
		MusicSystemDetails = musicSystemDetails;
	}

	@Override
	public String toString() {
		return "Car [make=" + make + ", model=" + model + ", price=" + price + ", engineDetails=" + engineDetails
				+ ", MusicSystemDetails=" + MusicSystemDetails + "]";
	}
	
}
