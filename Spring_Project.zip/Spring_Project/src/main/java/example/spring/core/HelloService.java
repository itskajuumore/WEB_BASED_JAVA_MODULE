package example.spring.core;

public class HelloService implements GreetingService {

	@Override
	public String sayGreeting() {
		// TODO Auto-generated method stub
		return "Hello from Spring";
	}
}

