package example.spring.core.without_xml;

import java.util.Arrays;
import java.util.Collection;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Configuration   //Marks this class as a Configuration Unit
@ComponentScan(basePackages={"another","third","Last","example"})
public class Springconfig {
	@Bean //marks this method as a Bean Configuration specific method.
	public GreentingImpl getGreentingImpl () {
		GreentingImpl gi= new GreentingImpl();
		return gi;
	}
	
	//configuration a bean of type MessageImpl with some 
	//different ID:myMessage
	
@Bean("myMessage")//Changing the default ID to myMessage
public MessageImpl getMessageImpl() {
	MessageImpl mi=new MessageImpl();
	return mi;
}

//Configuration a bean of type:java.util.Collection
@Bean("allCourses")
public Collection<String>getCourseList(){
	Collection<String>courseList=
			Arrays.asList("Corejava","Spring", "React", "Angular","AWS");
	return courseList;
}

@Bean("myTest")
@Lazy//Marks this bean as lazy so that it gets loadeed lazily.
//this is equivalent of lazy-init="true".
@Scope("prototype")//Marks this bean with scope as 'Prototype'
//this is equivalent of scopr="prototype
public TestImpl getTestImpl() {
	TestImpl ti= new TestImpl();
	return ti;
	
	
}
}
