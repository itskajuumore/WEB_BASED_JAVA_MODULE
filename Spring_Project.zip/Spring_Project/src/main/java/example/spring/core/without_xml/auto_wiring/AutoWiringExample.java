package example.spring.core.without_xml.auto_wiring;

import java.text.Annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AutoWiringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext(AppSpringConfig.class);
Object loadedobject=context.getBean("mycar");
System.out.println(loadedobject);
	}

}
