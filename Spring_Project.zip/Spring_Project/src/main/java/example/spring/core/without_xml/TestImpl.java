package example.spring.core.without_xml;

public class TestImpl {

	public TestImpl() {
		// TODO Auto-generated constructor stub
		System.out.println("Inside TestImpl()");
	}

}
