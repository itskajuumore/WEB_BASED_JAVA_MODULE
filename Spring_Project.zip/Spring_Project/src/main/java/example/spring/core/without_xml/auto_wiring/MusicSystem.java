package example.spring.core.without_xml.auto_wiring;

public class MusicSystem {
private String make;
private String sounEffect;
	public MusicSystem() {
		// TODO Auto-generated constructor stub
	}
	public MusicSystem(String make, String sounEffect) {
		super();
		this.make = make;
		this.sounEffect = sounEffect;
	}
	
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	public String getSounEffect() {
		return sounEffect;
	}
	public void setSounEffect(String sounEffect) {
		this.sounEffect = sounEffect;
	}
	@Override
	public String toString() {
		return "MusicSystem [make=" + make + ", sounEffect=" + sounEffect + "]";
	}
	

}
