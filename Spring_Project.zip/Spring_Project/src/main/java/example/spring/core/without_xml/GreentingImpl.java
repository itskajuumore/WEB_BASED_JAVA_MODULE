package example.spring.core.without_xml;

public class GreentingImpl {
public void doGreet() {
	System.out.println("Hello, Good Morning!!");
}
}
