package example.spring.aop;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component
@ComponentScan
@EnableAspectJAutoProxy //Enables Proxy generation support
public class AopSpringConfig {
//Addional bean cofigurations using @Bean if any.
}
