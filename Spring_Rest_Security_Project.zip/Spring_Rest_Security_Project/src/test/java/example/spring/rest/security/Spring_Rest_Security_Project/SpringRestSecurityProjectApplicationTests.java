package example.spring.rest.security.Spring_Rest_Security_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestSecurityProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
