package example.spring.rest.security.Spring_Rest_Security_Project;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SpringSecurityRestController {
	@GetMapping("/doGreet")
	public String getGreeting() {
		return "Welcome to Spring Security";
	}
	@GetMapping("/doAdminWork")//This resource is accessible only to admin users
	public String doAdminWork() {
		return "Doing admin work";
	}
	//This resource is accessible only to Regular users
	@GetMapping("/doRegularWork")
	public String doRefularWork() {
		return "Doing Regular work";
	}
}
