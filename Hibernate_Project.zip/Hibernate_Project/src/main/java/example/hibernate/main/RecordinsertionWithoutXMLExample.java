package example.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import example.hibernate.entity.Actor;
import example.hibernate.utils.HibernateConfig;


public class RecordinsertionWithoutXMLExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 try(
 SessionFactory factory= HibernateConfig.getSessionFactory();
		 Session session=factory.openSession();
 ){
	
	 Actor actorObj= new Actor("AO3", "Ranveer", "Singh", 40);
	 Transaction tx=session.beginTransaction();
	 session.persist(actorObj);
	 tx.commit();
	 System.out.println("Record inserted");
 }catch(Exception ex) {
	 ex.printStackTrace();
 }
	}

}
