package example.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import example.hibernate.entity.Movie;

public class RecordinsertionExample {

	public static void main(String[] args) {
		// Configure Hibernate using 'Configuration' class.
		Configuration conf=new Configuration();
		conf=conf.configure();
		
		//obtain a SessionFactory using 'Configuration' class.
		SessionFactory factory=conf.buildSessionFactory();
		
		//obtain a Session using SessionFactory
		Session currentSession=factory.openSession();
		
		//Create  an entity class object.
		Movie movieObject = new Movie("MO1", "Baby", "Action", 2013);
		
		//obtaion a Transaction and start the same
		Transaction tx= currentSession.beginTransaction();
		
		//Store the entity class object using a Session
		currentSession.persist(movieObject);
		
		//Commit the Transaction
		tx.commit();
		
		//Close the sesssion
		currentSession.close();
		
		//Close the SessionFactory
		factory.close();
		System.out.println("Record added..");

	}

}
