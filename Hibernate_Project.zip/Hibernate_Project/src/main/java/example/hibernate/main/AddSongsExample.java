package example.hibernate.main;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import example.hibernate.entity.Film;

import example.hibernate.entity.Song;

import example.hibernate.utils.HibernateConfig;



public class AddSongsExample {



	public static void main(String[] args) {

		// TODO Auto-generated method stub

		try(

				SessionFactory factory=HibernateConfig.getSessionFactory();

				Session session=factory.openSession()){

	       Song s1=new Song("S01","Kehana Hi Kya");

	       Song s2=new Song("S02","Millinior");

	       Song s3=new Song("S03","Blue Films");

	       Song s4=new Song("S04","Tu hi re");

	    
			Transaction tx=session.beginTransaction();

			session.persist(s1);

			session.persist(s2);

			session.persist(s3);

			session.persist(s4);

			tx.commit();

			System.out.println("Songs Added");

			

		}catch(Exception ex) {

			ex.printStackTrace();

		}



	}



}