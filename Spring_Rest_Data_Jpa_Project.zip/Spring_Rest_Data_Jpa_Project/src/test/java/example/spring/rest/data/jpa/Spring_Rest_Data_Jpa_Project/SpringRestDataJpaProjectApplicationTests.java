package example.spring.rest.data.jpa.Spring_Rest_Data_Jpa_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestDataJpaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
