package book_library.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import book_library.entity.Book;
//@Repository is not required because JpaRepository is already a managed compnonent and since BookRepository is inherited from it, also becomes a managed component since
public interface BookRepository extends JpaRepository<Book, Integer>{}
	



