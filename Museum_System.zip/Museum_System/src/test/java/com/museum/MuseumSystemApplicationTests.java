package com.museum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MuseumSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
