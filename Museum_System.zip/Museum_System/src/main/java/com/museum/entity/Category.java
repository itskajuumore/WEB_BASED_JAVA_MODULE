package com.museum.entity;

public enum Category {
PANTING, SCULPTURE, ARTIFACT
}
