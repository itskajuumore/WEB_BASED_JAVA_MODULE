package com.museum.service;
import com.museum.dao.ArticalRepository;
import org.springframework.beans.factory.annotation.Autowired;

import com.museum.entity.Article;

public class ArticleService {
	
	@Autowired
	private ArticalRepository articleRepo;

	public Article addArticle(Article article) {
		Article savedArticle=articleRepo.save(article);
		return savedArticle;
		
	}
}
