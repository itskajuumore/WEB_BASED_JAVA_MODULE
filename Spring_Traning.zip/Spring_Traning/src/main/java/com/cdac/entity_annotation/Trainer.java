package com.cdac.entity_annotation;

public interface Trainer {

	void train();
}
