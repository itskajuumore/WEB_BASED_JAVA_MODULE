package com.cdac.entity_annotation;

public interface TrainingCenter {

	void conductTraining();
}
