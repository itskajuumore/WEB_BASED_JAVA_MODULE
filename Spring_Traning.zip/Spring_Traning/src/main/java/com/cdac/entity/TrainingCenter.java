package com.cdac.entity;

public interface TrainingCenter {

	void conductTraining();
}
