package com.example.Library.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Library.dao.BookRepository;
import com.example.Library.dao.GenreRepository;
import com.example.Library.entity.Book;
import com.example.Library.entity.Genre;


@Service
public class BookService implements IBookService {

	@Autowired
	private BookRepository bookRepository;
	
	@Autowired
	private GenreRepository genreRepository;

	
	@Override
	public Book addBook(Book book) {
		// TODO Auto-generated method stub
		return bookRepository.save(book);
	}

	public List<Book> allBooks() {
		// TODO Auto-generated method stub
		return bookRepository.findAll();
	}
	

}