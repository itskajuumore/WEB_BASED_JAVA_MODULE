package com.example.Library.service;

import java.util.List;

import com.example.Library.entity.Book;

public interface IBookService {

	
	//Add Books
	Book addBook(Book book);
	
	
	//show Books
	List<Book>allBooks();
	
}
